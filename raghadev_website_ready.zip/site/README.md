# Raghadev Design Consultancy – website

Static website (plain HTML/CSS/JS, no server, no database).

## Before going live – checklist
1. Replace placeholder phone / email in index.html and Services/*/*.html
2. Create a free Formspree form and replace YOUR_UNIQUE_ID_HERE in index.html
3. Add real photos (project1-3.jpg, house*-main.jpg etc.) and remove the "Under Construction" bar
4. Never commit passwords, API keys or client documents to this repo (it is public)
